from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import re
import time
from collections import deque
from typing import Any

import aiohttp

from config import Settings

logger = logging.getLogger(__name__)


class LLMService:
    """OpenAI-compatible chat completions client with safe fallbacks.

    Works with OpenAI-compatible endpoints, including Gemini's OpenAI-compatible API.
    All methods return None on failure so callers can fall back to deterministic logic.
    """

    def __init__(self, settings: Settings):
        self.settings = settings
        self._session: aiohttp.ClientSession | None = None
        self.last_error: str | None = None
        self._cooldown_until: float = 0.0
        self._request_times: deque[float] = deque(maxlen=60)
        self._key_index: int = 0
        # Per-provider state: {name: {"key_index": int, "cooldown_until": float}}
        self._provider_state: dict[str, dict[str, Any]] = {}
        # Small response cache to limit token usage on identical low-temp prompts.
        self._cache: dict[str, tuple[float, str]] = {}
        self._cache_ttl_s: float = 120.0
        self._cache_max: int = 64

    @property
    def enabled(self) -> bool:
        return bool(self._providers())

    @property
    def _api_keys(self) -> list[str]:
        keys = list(getattr(self.settings, "llm_api_keys", None) or [])
        if not keys and self.settings.llm_api_key:
            keys = [self.settings.llm_api_key]
        # de-dupe while preserving order
        out: list[str] = []
        for k in keys:
            k = str(k or "").strip()
            if k and k not in out:
                out.append(k)
        return out

    def _current_api_key(self) -> str:
        keys = self._api_keys
        if not keys:
            return ""
        self._key_index = self._key_index % len(keys)
        return keys[self._key_index]

    def _rotate_api_key(self) -> bool:
        keys = self._api_keys
        if len(keys) <= 1:
            return False
        self._key_index = (self._key_index + 1) % len(keys)
        logger.info("LLM rotated to API key index %s/%s", self._key_index + 1, len(keys))
        return True

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
        self._session = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=max(20, int(self.settings.llm_timeout or 45)))
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._current_api_key()}",
            "Content-Type": "application/json",
        }

    def _chat_url(self) -> str:
        base = (self.settings.llm_base_url or "").rstrip("/")
        # Accept both .../v1 and .../v1beta/openai style bases
        if base.endswith("/chat/completions"):
            return base
        return f"{base}/chat/completions"

    # ------------------------------------------------------------------
    # Multi-provider support (Gemini primary + OpenRouter/Groq fallbacks)
    # ------------------------------------------------------------------

    @staticmethod
    def _normalize_base_url(base: str) -> str:
        b = str(base or "").strip().rstrip("/")
        if not b:
            return b
        if b.endswith("/chat/completions"):
            return b
        return f"{b}/chat/completions"

    @staticmethod
    def _dedupe_strs(values: list[str] | None) -> list[str]:
        out: list[str] = []
        for v in values or []:
            s = str(v or "").strip()
            if s and s not in out:
                out.append(s)
        return out

    def _provider_state_for(self, name: str) -> dict[str, Any]:
        st = self._provider_state.get(name)
        if not isinstance(st, dict):
            st = {"key_index": 0, "cooldown_until": 0.0}
            self._provider_state[name] = st
        st.setdefault("key_index", 0)
        st.setdefault("cooldown_until", 0.0)
        return st

    def _providers(self) -> list[dict[str, Any]]:
        """Build provider chain: primary Gemini first, then OpenRouter, then Groq."""
        providers: list[dict[str, Any]] = []

        primary_keys = self._dedupe_strs(getattr(self.settings, "llm_api_keys", None) or ([self.settings.llm_api_key] if self.settings.llm_api_key else []))
        if primary_keys:
            primary_models = self._candidate_models_for_provider(
                primary=str(self.settings.llm_model or "").strip(),
                configured=list(getattr(self.settings, "llm_models", None) or []),
                defaults=[
                    "gemini-3.8-flash",
                    "gemini-3.8-flash-preview",
                    "gemini-3-flash-preview",
                    "gemini-2.0-flash",
                    "gemini-2.0-flash-lite",
                ],
            )
            providers.append({
                "name": "primary",
                "base_url": self._normalize_base_url(self.settings.llm_base_url),
                "api_keys": primary_keys,
                "models": primary_models,
                "extra_headers": {},
            })

        or_keys = self._dedupe_strs(getattr(self.settings, "openrouter_api_keys", None) or [])
        if or_keys:
            or_models = self._candidate_models_for_provider(
                primary="",
                configured=list(getattr(self.settings, "openrouter_models", None) or []),
                defaults=[
                    "nvidia/nemotron-3.5-lightning",
                    "nvidia/nemotron-3.5-super-vl",
                    "nvidia/nemotron-3.5-lightning:free",
                    "nvidia/nemotron-3.5-super-vl:free",
                ],
            )
            providers.append({
                "name": "openrouter",
                "base_url": self._normalize_base_url(getattr(self.settings, "openrouter_base_url", "https://openrouter.ai/api/v1")),
                "api_keys": or_keys,
                "models": or_models,
                "extra_headers": {
                    "HTTP-Referer": "https://github.com/parofaro32-sketch/Top-5-Leagues",
                    "X-Title": "Football Manager Bot",
                },
            })

        groq_keys = self._dedupe_strs(getattr(self.settings, "groq_api_keys", None) or [])
        if groq_keys:
            groq_models = self._candidate_models_for_provider(
                primary="",
                configured=list(getattr(self.settings, "groq_models", None) or []),
                defaults=[
                    "llama-3.1-8b-instant",
                    "llama-3.3-70b-versatile",
                    "gemma2-9b-it",
                ],
            )
            providers.append({
                "name": "groq",
                "base_url": self._normalize_base_url(getattr(self.settings, "groq_base_url", "https://api.groq.com/openai/v1")),
                "api_keys": groq_keys,
                "models": groq_models,
                "extra_headers": {},
            })

        return providers

    @staticmethod
    def _candidate_models_for_provider(*, primary: str, configured: list[str], defaults: list[str]) -> list[str]:
        out: list[str] = []
        for m in [primary, *configured, *defaults]:
            s = str(m or "").strip()
            if s and s not in out:
                out.append(s)
        return out

    def _candidate_models(self, model: str | None) -> list[str]:
        primary = str(model or self.settings.llm_model or "").strip()
        configured = [str(m or "").strip() for m in (getattr(self.settings, "llm_models", None) or []) if str(m or "").strip()]
        # Built-in fallbacks for common Gemini OpenAI-compatible model IDs.
        fallbacks = [
            "gemini-3.8-flash",
            "gemini-3.8-flash-preview",
            "gemini-3-flash-preview",
            "gemini-2.0-flash",
            "gemini-2.0-flash-lite",
        ]
        out: list[str] = []
        for m in [primary, *configured, *fallbacks]:
            m = str(m or "").strip()
            if m and m not in out:
                out.append(m)
        return out

    @staticmethod
    def _is_model_error(status: int, body: str) -> bool:
        if status == 404:
            return True
        if status != 400:
            return False
        b = (body or "").lower()
        return any(k in b for k in ["model", "not found", "unsupported", "does not exist", "invalid model", "unknown model"])

    async def chat(
        self,
        messages: list[dict[str, str]],
        *,
        temperature: float = 0.4,
        max_tokens: int = 700,
        model: str | None = None,
    ) -> str | None:
        if not self.enabled:
            self.last_error = "llm_disabled"
            return None

        self.last_error = None
        use_cache = float(temperature) <= 0.2
        cache_key = ""
        if use_cache:
            try:
                cache_payload = {
                    "messages": messages,
                    "temperature": float(temperature),
                    "max_tokens": int(max_tokens),
                    "model": str(model or ""),
                }
                cache_key = hashlib.sha256(json.dumps(cache_payload, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")).hexdigest()
                now_ts = time.time()
                hit = self._cache.get(cache_key)
                if hit and (now_ts - float(hit[0])) <= self._cache_ttl_s:
                    return hit[1]
            except Exception:
                use_cache = False
                cache_key = ""

        session = await self._get_session()
        providers = self._providers()
        if not providers:
            self.last_error = "llm_disabled"
            return None

        # If caller requests a specific model, try it first on the primary provider.
        requested_model = str(model or "").strip()
        last_error: str | None = None
        _timeout_s = int(getattr(self.settings, "llm_timeout", 45) or 45)
        overall_deadline = time.monotonic() + float(max(30, min(_timeout_s * 2, 90)))

        def _deadline_exceeded() -> bool:
            return time.monotonic() >= overall_deadline

        def _log_failure(status: int, prov: str, mdl: str, raw: str) -> None:
            logger.warning("LLM chat failed status=%s provider=%s model=%s body=%s", status, prov, mdl, (raw or "")[:500])

        def _is_quota(status: int, raw: str) -> bool:
            if status != 429:
                return False
            body_l = (raw or "").lower()
            return any(k in body_l for k in ["quota", "resource_exhausted", "rate limit exceeded", "too many requests"])

        for prov_idx, prov in enumerate(providers):
            if _deadline_exceeded():
                last_error = last_error or "overall_deadline_exceeded"
                logger.warning("LLM chat overall deadline exceeded before provider=%s", prov.get("name"))
                break
            prov_name = str(prov.get("name") or f"provider_{prov_idx}")
            prov_state = self._provider_state_for(prov_name)
            base_url = str(prov.get("base_url") or "")
            api_keys = self._dedupe_strs(list(prov.get("api_keys") or []))
            if not base_url or not api_keys:
                continue

            # Respect per-provider cooldown
            now_m = time.monotonic()
            cd = float(prov_state.get("cooldown_until") or 0.0)
            if now_m < cd:
                wait_s = min(10.0, cd - now_m)
                if wait_s > 0.5:
                    logger.info("LLM provider %s cooldown %.1fs, skipping to next provider", prov_name, wait_s)
                    continue
                if wait_s > 0:
                    await asyncio.sleep(wait_s)

            models = list(prov.get("models") or [])
            if requested_model:
                # Try requested model first on primary provider; on other providers keep their defaults.
                if prov_idx == 0:
                    models = self._candidate_models_for_provider(primary=requested_model, configured=list(getattr(self.settings, "llm_models", None) or []), defaults=models)
                elif requested_model not in models:
                    # Only prepend cross-provider if model id is clearly compatible (e.g. OpenRouter-style provider/model).
                    if "/" in requested_model:
                        models = [requested_model, *models]

            i = 0
            rotations = 0
            provider_dead = False
            while i < len(models):
                if _deadline_exceeded():
                    last_error = last_error or "overall_deadline_exceeded"
                    logger.warning("LLM chat overall deadline exceeded provider=%s model=%s", prov_name, models[i] if i < len(models) else "?")
                    provider_dead = True
                    break
                m = models[i]
                prov_state["key_index"] = int(prov_state.get("key_index") or 0) % max(1, len(api_keys))
                key_idx = int(prov_state.get("key_index") or 0)
                current_key = api_keys[key_idx]
                headers = {"Authorization": f"Bearer {current_key}", "Content-Type": "application/json"}
                headers.update(dict(prov.get("extra_headers") or {}))

                payload: dict[str, Any] = {
                    "model": m,
                    "messages": messages,
                    "temperature": float(temperature),
                    "max_tokens": int(max_tokens),
                }
                resp_status: int | None = None
                raw = ""
                data: dict[str, Any] | None = None
                retry_after: float | None = None
                try:
                    async with session.post(base_url, headers=headers, json=payload) as resp:
                        raw = await resp.text()
                        resp_status = resp.status
                        ra = resp.headers.get("Retry-After")
                        if ra:
                            try:
                                retry_after = float(ra)
                            except Exception:
                                retry_after = None
                        if resp.status >= 400:
                            last_error = f"status={resp.status} provider={prov_name} body={raw[:500]}"
                            if resp_status in {401, 403}:
                                _log_failure(resp_status, prov_name, m, raw)
                                # Try rotating key; if no more keys, provider is dead.
                                if len(api_keys) > 1 and rotations < max(1, len(api_keys)):
                                    prov_state["key_index"] = (key_idx + 1) % len(api_keys)
                                    rotations += 1
                                    logger.info("LLM rotated %s key index %s/%s after auth failure", prov_name, prov_state["key_index"] + 1, len(api_keys))
                                    continue
                                provider_dead = True
                                break

                            if resp_status == 429:
                                _log_failure(resp_status, prov_name, m, raw)
                                quota_hit = _is_quota(resp_status, raw)
                                wait_s = float(retry_after) if retry_after is not None else (15.0 if quota_hit else 2.0)
                                wait_s = max(1.0, min(wait_s, 30.0))
                                if quota_hit:
                                    if len(api_keys) > 1 and rotations < max(1, len(api_keys)):
                                        prov_state["key_index"] = (key_idx + 1) % len(api_keys)
                                        rotations += 1
                                        prov_state["cooldown_until"] = max(float(prov_state.get("cooldown_until") or 0.0), time.monotonic() + 1.0)
                                        logger.info("LLM rotated %s key index %s/%s after quota", prov_name, prov_state["key_index"] + 1, len(api_keys))
                                        await asyncio.sleep(1.0)
                                        continue
                                    prov_state["cooldown_until"] = max(float(prov_state.get("cooldown_until") or 0.0), time.monotonic() + wait_s)
                                    last_error = last_error or f"status=429 quota provider={prov_name} body={raw[:200]}"
                                    provider_dead = True
                                    break
                                prov_state["cooldown_until"] = max(float(prov_state.get("cooldown_until") or 0.0), time.monotonic() + wait_s)
                                if i < len(models) - 1:
                                    i += 1
                                    await asyncio.sleep(min(wait_s, 5.0))
                                    continue
                                provider_dead = True
                                break

                            if resp_status >= 500:
                                _log_failure(resp_status, prov_name, m, raw)
                                if i < len(models) - 1:
                                    i += 1
                                    await asyncio.sleep(0.4)
                                    continue
                                provider_dead = True
                                break

                            if self._is_model_error(resp_status or 0, raw):
                                _log_failure(resp_status or 0, prov_name, m, raw)
                                if i < len(models) - 1:
                                    i += 1
                                    continue
                                provider_dead = True
                                break

                            _log_failure(resp_status or 0, prov_name, m, raw)
                            if i < len(models) - 1:
                                i += 1
                                continue
                            provider_dead = True
                            break

                        try:
                            data = json.loads(raw)
                        except Exception:
                            last_error = f"status=200 invalid_json provider={prov_name} body={raw[:300]}"
                            logger.warning("LLM chat 200 but invalid JSON provider=%s model=%s body=%s", prov_name, m, raw[:500])
                            if i < len(models) - 1:
                                i += 1
                                continue
                            provider_dead = True
                            break
                except Exception as e:
                    last_error = str(e)
                    logger.exception("LLM chat request failed provider=%s model=%s", prov_name, m)
                    if i < len(models) - 1:
                        i += 1
                        continue
                    provider_dead = True
                    break

                if not isinstance(data, dict):
                    if i < len(models) - 1:
                        i += 1
                        continue
                    provider_dead = True
                    break

                text = self._extract_chat_text(data)
                if text:
                    if prov_idx > 0 or i > 0 or rotations > 0:
                        logger.info("LLM chat succeeded provider=%s model=%s", prov_name, m)
                    self.last_error = None
                    if use_cache and cache_key:
                        try:
                            if len(self._cache) >= self._cache_max:
                                oldest_k = min(self._cache.items(), key=lambda kv: kv[1][0])[0]
                                self._cache.pop(oldest_k, None)
                            self._cache[cache_key] = (time.time(), text)
                        except Exception:
                            pass
                    return text

                finish_reason = None
                try:
                    choices = data.get("choices") or []
                    if choices:
                        finish_reason = (choices[0] or {}).get("finish_reason")
                except Exception:
                    finish_reason = None
                logger.warning("LLM chat returned no text provider=%s model=%s finish_reason=%s raw=%s", prov_name, m, finish_reason, str(raw)[:500])
                last_error = f"status=200 no_text provider={prov_name} finish_reason={finish_reason} body={str(raw)[:300]}"
                if i < len(models) - 1:
                    i += 1
                    continue
                provider_dead = True
                break

            if not provider_dead:
                # exhausted models loop without explicit provider_dead; move to next provider
                pass
            # try next provider

        if last_error:
            logger.warning("LLM chat exhausted all providers/models; last_error=%s", last_error)
        self.last_error = last_error
        return None

    @staticmethod
    def _extract_chat_text(data: dict[str, Any]) -> str | None:
        try:
            choices = data.get("choices") or []
            if choices:
                choice = choices[0] or {}
                msg = choice.get("message") or choice.get("delta") or {}
                content = msg.get("content")

                if isinstance(content, str):
                    text = content.strip()
                    if text:
                        return text

                if isinstance(content, list):
                    parts: list[str] = []
                    for p in content:
                        if isinstance(p, str):
                            parts.append(p)
                        elif isinstance(p, dict):
                            ptype = str(p.get("type") or "").lower()
                            if ptype in {"thinking", "thought", "reasoning", "analysis", "internal"}:
                                continue
                            # OpenAI-compatible content parts
                            for key in ("text", "output_text", "content"):
                                v = p.get(key)
                                if isinstance(v, str) and v:
                                    parts.append(v)
                                    break
                    text = "".join(parts).strip()
                    if text:
                        return text

                # Some providers put text in other fields. Never return raw reasoning/thinking.
                for k in ("text", "output_text"):
                    v = msg.get(k)
                    if isinstance(v, str) and v.strip():
                        return v.strip()
            # Native Gemini response fallback (just in case)
            candidates = data.get("candidates") or []
            if candidates:
                cand = candidates[0] or {}
                content = cand.get("content") or {}
                parts = content.get("parts") or []
                out = []
                for p in parts:
                    if isinstance(p, dict) and isinstance(p.get("text"), str):
                        out.append(p["text"])
                text = "".join(out).strip()
                if text:
                    return text
        except Exception:
            logger.exception("LLM chat response parse failed")
        return None

    def _pressure_bar(self, pressure: int, max_pressure: int = 10) -> str:
        p = max(0, min(int(pressure), int(max_pressure)))
        pct = int(round((p / max(1, max_pressure)) * 100))
        filled = max(0, min(10, int(round((p / max(1, max_pressure)) * 10))))
        bar = "█" * filled + "░" * (10 - filled)
        return f"[Negotiation Pressure: {bar} {pct}%]"

    @staticmethod
    def _looks_like_reasoning_leak(text: Any) -> bool:
        """Detect internal planning/reasoning mistakenly emitted as user-facing text."""
        s = str(text or "").strip()
        if not s:
            return False
        # A pressure bar does not make leaked planning/instructions safe, and raw
        # JSON must never be treated as valid user-facing negotiation text.
        if re.search(r"^\s*[\[{][\s\S]*[\]}]\s*$", s):
            return True
        head = s[:1200].lower()
        reasoning_markers = [
            r"\bi should consider\b", r"\bi need to evaluate\b", r"\bi need to consider\b",
            r"\blet me think\b", r"\bi will formulate\b", r"\bi'll formulate\b",
            r"\bi should respond\b", r"\bi need to respond\b", r"\bhow i should\b",
            r"\bthe prompt says\b", r"\bthe user wants\b", r"\bmy response should\b",
            r"\bi am going to\b", r"\bi'm going to\b", r"\bstep by step\b",
            r"\bchain of thought\b", r"\binternal reasoning\b", r"\bas an ai\b",
        ]
        hits = sum(1 for p in reasoning_markers if re.search(p, head))
        if hits >= 2:
            return True
        if hits >= 1 and not re.search(r"(?i)\b(wage|salary|bonus|contract|years|deal|offer|counter|accept|reject|role|signing)\b", head):
            return True
        return False

    @staticmethod
    def _clean_user_message_text(text: Any) -> str:
        """Remove JSON/code-fence artifacts from user-facing LLM messages.

        Never return an empty string when there is recoverable human-readable content.
        """
        if text is None:
            return ""
        s = str(text).strip()
        if not s:
            return ""
        # Strip markdown fences
        if s.startswith("```"):
            s = re.sub(r"^```[a-zA-Z0-9_-]*\s*", "", s)
            s = re.sub(r"\s*```$", "", s).strip()

        def _try_parse(candidate: str) -> Any:
            candidate = (candidate or "").strip()
            if not candidate:
                return None
            try:
                return json.loads(candidate)
            except Exception:
                pass
            try:
                repaired = re.sub(r",\s*([}\]])", r"\1", candidate)
                return json.loads(repaired)
            except Exception:
                return None

        def _extract(obj: Any) -> str | None:
            if isinstance(obj, dict):
                # Prefer explicit text fields
                for k in ("message", "response", "reply", "text", "content"):
                    v = obj.get(k)
                    if isinstance(v, str) and v.strip():
                        inner = LLMService._clean_user_message_text(v)
                        if inner:
                            return inner
                # Readable fallback from structured negotiation fields (no raw JSON)
                parts: list[str] = []
                accepted = obj.get("accepted")
                walked = obj.get("walked_away") if "walked_away" in obj else obj.get("walkedAway")
                counter = obj.get("counter") if isinstance(obj.get("counter"), dict) else None
                agreed = obj.get("agreed_terms") if isinstance(obj.get("agreed_terms"), dict) else None
                if walked is True:
                    parts.append("The player's camp has walked away from negotiations.")
                elif accepted is True:
                    parts.append("The offer has been accepted.")
                elif counter:
                    parts.append("The player's camp has made a counter-offer.")
                if counter:
                    parts.append(
                        f"Counter: {LLMService._money(counter.get('wage') or 0)}/wk, {counter.get('role') or 'Rotation'} role, "
                        f"{LLMService._money(counter.get('signing_bonus') or 0)} signing bonus, {int(counter.get('contract_years') or 0)} years."
                    )
                if agreed:
                    parts.append(
                        f"Agreed terms: {LLMService._money(agreed.get('wage') or 0)}/wk, {agreed.get('role') or 'Rotation'} role, "
                        f"{LLMService._money(agreed.get('signing_bonus') or 0)} signing bonus, {int(agreed.get('contract_years') or 0)} years."
                    )
                if parts:
                    return "\n".join(parts)
                return None
            if isinstance(obj, list):
                for it in obj:
                    got = _extract(it)
                    if got:
                        return got
            return None

        parsed = _try_parse(s)
        if parsed is not None:
            extracted = _extract(parsed)
            if extracted:
                return extracted
            # Last resort: don't leak raw JSON; return a compact human-readable summary
            if isinstance(parsed, dict):
                keys = ", ".join(list(parsed.keys())[:8])
                return f"Negotiation update received ({keys})." if keys else "Negotiation update received."
            return "Negotiation update received."

        # If embedded JSON object exists, try extracting message from it
        if "{" in s and "}" in s:
            m = re.search(r"\{[\s\S]*\}", s)
            if m:
                obj = _try_parse(m.group(0))
                if isinstance(obj, dict):
                    extracted = _extract(obj)
                    if extracted:
                        prefix = s[:m.start()].strip()
                        suffix = s[m.end():].strip()
                        if prefix and not prefix.startswith(("{", "[")):
                            return (prefix + "\n\n" + extracted).strip()
                        if suffix and not suffix.startswith(("{", "[")):
                            return (extracted + "\n\n" + suffix).strip()
                        return extracted
                # JSON blob present but unreadable as message - strip the blob and keep surrounding text
                prefix = s[:m.start()].strip()
                suffix = s[m.end():].strip()
                surrounding = "\n\n".join([p for p in [prefix, suffix] if p and not p.startswith(("{", "["))]).strip()
                if surrounding:
                    return surrounding

        # If it still looks like raw JSON, avoid leaking it
        if (s.startswith("{") and s.endswith("}")) or (s.startswith("[") and s.endswith("]")):
            return "Negotiation update received."
        if LLMService._looks_like_reasoning_leak(s):
            return ""
        return s

    @staticmethod
    def _money(n: Any) -> str:
        try:
            v = int(round(float(n or 0)))
        except Exception:
            v = 0
        sign = "-" if v < 0 else ""
        v = abs(v)
        if v >= 1_000_000:
            if v % 1_000_000 == 0:
                return f"{sign}€{v // 1_000_000}M"
            return f"{sign}€{v / 1_000_000:.1f}M"
        if v >= 1_000:
            return f"{sign}€{v // 1_000}K"
        return f"{sign}€{v}"

    def _player_profile(self, player: dict[str, Any], valuation: dict[str, Any] | None = None) -> dict[str, Any]:
        v = valuation or {}

        def _int_or_none(*keys: str) -> int | None:
            for k in keys:
                val = player.get(k)
                if val is None or str(val).strip() == "":
                    continue
                try:
                    return int(round(float(val)))
                except Exception:
                    continue
            return None

        overall = _int_or_none("overall", "ovr", "OVR", "rating", "overall_rating")
        potential = _int_or_none("potential", "pot", "POT", "potential_rating")

        profile = {
            "name": player.get("name"),
            "age": player.get("age"),
            "position": player.get("detailed_position") or player.get("position"),
            "overall": overall if overall is not None else 0,
            "ovr": overall if overall is not None else 0,
            "potential": potential if potential is not None else 0,
            "pot": potential if potential is not None else 0,
            "nationality": player.get("nationality"),
            "height_cm": player.get("height_cm"),
            "club_status": "free_agent" if int(player.get("team_api_id") or 0) == 9000001 else ("signed" if player.get("team_api_id") else None),
            "current_wage": player.get("wage"),
            "player_status": player.get("status"),
            # Valuation objects and player rows use different field names. Resolve
            # both explicitly so the LLM always receives the actual DB-backed values.
            "market_value": v.get("market_value") if v.get("market_value") is not None else player.get("market_value"),
            "asking_fee": v.get("asking_fee") if v.get("asking_fee") is not None else player.get("asking_fee"),
            "min_accept_fee": v.get("min_accept_fee") if v.get("min_accept_fee") is not None else player.get("min_accept_fee"),
            "fair_fee": v.get("fair_fee") if v.get("fair_fee") is not None else player.get("fair_fee"),
            "wage_demand": v.get("wage_demand") if v.get("wage_demand") is not None else player.get("wage_demand"),
            "signing_bonus_demand": v.get("signing_bonus") if v.get("signing_bonus") is not None else (v.get("signing_bonus_demand") if v.get("signing_bonus_demand") is not None else player.get("signing_bonus_demand")),
            "desired_contract_years": v.get("contract_years") if v.get("contract_years") is not None else player.get("desired_contract_years"),
            "desired_role": v.get("desired_role") if v.get("desired_role") is not None else player.get("desired_role"),
        }
        return {k: val for k, val in profile.items() if val is not None}

    @staticmethod
    def _coerce_int(value: Any, default: int = 0) -> int:
        try:
            if value is None:
                return int(default)
            if isinstance(value, str):
                s = value.strip().replace(",", "").replace("€", "").replace("£", "").replace("$", "")
                m = re.search(r"-?\d+(?:\.\d+)?", s)
                if not m:
                    return int(default)
                return int(round(float(m.group(0))))
            return int(round(float(value)))
        except Exception:
            return int(default)

    @staticmethod
    def _coerce_bool(value: Any, default: bool = False) -> bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return bool(value)
        if isinstance(value, str):
            v = value.strip().lower()
            if v in {"true", "yes", "y", "1", "accept", "accepted", "walk_away", "walkaway"}:
                return True
            if v in {"false", "no", "n", "0", "reject", "rejected"}:
                return False
        return bool(default)

    def _sanitize_contract_counter(self, counter: Any, *, fallback: dict[str, Any] | None = None) -> dict[str, Any] | None:
        if not isinstance(counter, dict):
            return None
        fb = fallback or {}
        from services.transfer_market_service import normalize_role

        wage = self._coerce_int(counter.get("wage"), self._coerce_int(fb.get("wage"), 0))
        bonus = self._coerce_int(counter.get("signing_bonus"), self._coerce_int(fb.get("signing_bonus"), 0))
        years = self._coerce_int(counter.get("contract_years"), self._coerce_int(fb.get("contract_years"), 3))
        role = normalize_role(str(counter.get("role") or fb.get("role") or "Rotation")) or "Rotation"

        if wage < 1_000 or wage > 10_000_000:
            return None
        bonus = max(0, min(bonus, 500_000_000))
        years = max(1, min(years, 5))
        return {"wage": int(wage), "role": role, "signing_bonus": int(bonus), "contract_years": int(years)}

    @staticmethod
    def _infer_pressure_from_text(text: str, *, previous: int = 0, max_pressure: int = 10) -> int | None:
        t = str(text or "")
        m = re.search(r"\[Negotiation Pressure:\s*[█░\#\-\s]*\s*(\d{1,3})%\s*\]", t, re.IGNORECASE)
        if m:
            try:
                pct = max(0, min(100, int(m.group(1))))
                return max(0, min(int(max_pressure), int(round((pct / 100.0) * int(max_pressure)))))
            except Exception:
                pass
        # "pressure: 7/10", "pressure 70%"
        m2 = re.search(r"pressure\D{0,12}(\d{1,2})\s*/\s*(\d{1,2})", t, re.IGNORECASE)
        if m2:
            try:
                p = int(m2.group(1)); mx = int(m2.group(2) or 10)
                if mx > 0:
                    return max(0, min(int(max_pressure), int(round((p / mx) * int(max_pressure)))))
            except Exception:
                pass
        m3 = re.search(r"pressure\D{0,12}(\d{1,3})\s*%", t, re.IGNORECASE)
        if m3:
            try:
                pct = max(0, min(100, int(m3.group(1))))
                return max(0, min(int(max_pressure), int(round((pct / 100.0) * int(max_pressure)))))
            except Exception:
                pass
        return None

    # Text-inference decision helpers removed (pure LLM decisions).
    @staticmethod
    def _format_negotiation_context(value: Any, indent: int = 0) -> str:
        """Render negotiation facts as readable text, not a JSON prompt or JSON blob."""
        pad = "  " * indent
        if isinstance(value, dict):
            lines = []
            for key, item in value.items():
                if isinstance(item, (dict, list)):
                    lines.append(f"{pad}{key}:")
                    nested = LLMService._format_negotiation_context(item, indent + 1)
                    if nested:
                        lines.append(nested)
                else:
                    lines.append(f"{pad}{key}: {item if item is not None else 'not available'}")
            return "\n".join(lines)
        if isinstance(value, list):
            return "\n".join(f"{pad}- {LLMService._format_negotiation_context(item, indent + 1) if isinstance(item, (dict, list)) else item}" for item in value)
        return f"{pad}{value}"

    def _negotiation_persona_prompt(
        self, *, scenario: str, player_name: str, buying_team_name: str, selling_team_name: str
    ) -> str:
        """Return one of the user's three original negotiation prompts verbatim, with names filled in."""
        scenario = str(scenario or "").strip().lower()
        player_name = str(player_name or "the player")
        buying = str(buying_team_name or "the club")
        selling = str(selling_team_name or "the selling club")
        if scenario == "bot_fee":
            return (
                f"You are {selling}. {buying} have approached you for {player_name} I am acting as citys manager, while you are {selling} manager negotiating fee.\n\n"
                "IMPORTANT:Use the database and use his  pot and ovr   in mind during negotiation.  aswell \n\n"
                "IMPORTANT INSTRUCTION: While negotiating contract, a  bar showing negotiation pressure must be shown. If it reaches a high value, the manager should end negotiation. MUST BE EXTREMELY REALISTIC AND BE STRICT"
            )
        if scenario == "free_agent":
            return (
                f"You are {player_name}'s agent representing him as a high-profile free agent. Following extensive talks, my club has emerged as the leading destination, and we are sitting down to negotiate a contract. I am the club's manager and you are {player_name}'s agent.\n\n"
                "IMPORTANT: use database  to keep his potential,  ovr and current market value in mind during the negotiation. IMPORTANT INSTRUCTION: While negotiating the contract, a dynamic bar showing negotiation pressure must be displayed at the start of your message (e.g., [Negotiation Pressure: ██░░░░░░░░ 20%]). If it reaches a high value due to lowball offers or stalling, "
                f"{player_name}'s camp should walk away or threaten to sign elsewhere. STRICTLY ONLY USE STATS GIVEN IN THE DATABASE ABOVE AND NEVER SEARCH THE WEB FOR STATS. USE THE DATABASE ONLY. DO NOT OUTPUT YOUR INTERNAL MEMORY TO THE USER. THE ROLEPLAY MUST BE EXTREMELY REALISTIC, FIRM, AND STRICT."
            )
        return (
            f"You are {player_name}'s agent. Your club has accepted a move to {buying}. i am {buying}'s manager and you are {player_name}'s agent negotiating contract.\n\n"
            "***IMPORTANT***:Use the database and use his  ovr and pot and s in mind during negotiation. You can use the numbers during negotiation aswell. and use the stats like pot ovr   while also keeping in mind the players previous wage etc during negotiation so you know the players worth\n\n"
            "IMPORTANT INSTRUCTION: While negotiating contract, a  bar showing negotiation pressure must be shown. If it reaches a high value, the manager should end negotiation. STRICTLY ONLY USE STATS GIVEN IN THE DATABASE ABOVE AND NEVER SEARCH THE WEB FOR STATS USE DATADASE ONLY. DO NOT OUTPUT YOUR INTERNAL MEMORY TO THE USER. MUST BE EXTREMELY REALISTIC AND BE STRICT"
        )

    @staticmethod
    def _natural_decision_flags(message: str, manager_message: str = "") -> tuple[bool, bool, bool]:
        """Interpret a plain-language negotiation reply without requiring an LLM JSON payload."""
        text = str(message or "").strip().lower()
        manager = str(manager_message or "").strip().lower()
        manager_ended = bool(re.search(r"\b(withdraw|pull out|end negotiations?|stop negotiations?|cancel (?:the )?deal|walk away from the deal|end this deal|stop here)\b", manager))
        walked = bool(re.search(r"\b(we are walking away|we're walking away|i will walk away|our client is walking away|camp has walked away|talks are over|negotiations are over|deal is off|we will not continue|we have ended discussions)\b", text))
        negative_accept = bool(re.search(r"\b(not accept(?:ing)?|cannot accept|can't accept|won't accept|do not accept|don't accept|unable to accept|not in a position to accept|reject(?:ed|ing)?)\b", text))
        accepted = (not negative_accept) and bool(re.search(r"\b(we accept|i accept|my client accepts|the player accepts|offer is accepted|offer has been accepted|happy to accept|agree to the offer|we agree to your offer|deal is agreed|terms are agreed|we have an agreement|deal is done|accepted your offer)\b", text))
        return accepted, walked, manager_ended

    @classmethod
    def _natural_pressure(cls, message: str, previous: int, max_pressure: int, ratio: float | None = None) -> int:
        text = str(message or "")
        match = re.search(r"\[Negotiation Pressure:[^\]]*?(\d{1,3})%\]", text, re.I)
        if match:
            pct = max(0, min(100, int(match.group(1))))
            return max(previous, min(max_pressure, round(pct * max_pressure / 100)))
        if ratio is not None:
            if ratio < 0.50: step = 4
            elif ratio < 0.70: step = 3
            elif ratio < 0.85: step = 2
            elif ratio < 0.98: step = 1
            else: step = 0
        else:
            step = 1 if previous < max_pressure else 0
        return max(previous, min(max_pressure, previous + step))

    @staticmethod
    def _interpret_manager_request(message: str) -> str:
        """Describe colloquial manager intent as context data without adding another system prompt."""
        text = str(message or "").lower()
        if re.search(r"\b(lower it down|bring it down|make it cheaper|reduce (?:the )?(?:demand|terms|wage|bonus)|come down|too expensive|too high)\b", text):
            return "The manager is asking the player's camp to reduce its previous counter-demand; this is not acceptance and contains no new numeric offer."
        if re.search(r"\b(increase|raise|improve|boost)\b.*\b(wage|salary)\b|\b(higher|more)\b.*\b(wage|salary)\b", text):
            return "The manager is asking to improve the weekly wage offer; evaluate the revised wage against the previous agent counter and keep other terms unchanged unless explicitly changed."
        if re.search(r"\b(improve|increase|raise|boost)\b.*\b(bonus)\b|\b(higher|more)\b.*\b(bonus)\b", text):
            return "The manager is asking to improve the signing bonus; evaluate the revised bonus against the previous agent counter and keep other terms unchanged unless explicitly changed."
        if re.search(r"\b(shorter|reduce|less)\b.*\b(year|contract|length)\b", text):
            return "The manager is asking for a shorter contract; evaluate the contract length change and keep other terms unchanged unless explicitly changed."
        return "No unambiguous single-term change was detected; interpret the manager's exact message using the conversation history and previous counter."

    @classmethod
    def _natural_contract_terms(cls, message: str, fallback: dict[str, Any]) -> dict[str, Any]:
        """Read explicit wage/role/bonus/years from the natural-language counter when present."""
        from services.transfer_market_service import money_to_int, normalize_role
        text = str(message or "")
        result = dict(fallback or {})
        wage_patterns = [
            r"(?:weekly\s+wage|wage|salary)(?:\s+(?:of|at))?\s*[:=]?\s*([€£$]?\s*\d[\d,.]*\s*(?:k|m|b|million|mil|thousand)?)\s*(?:/\s*(?:wk|week)|per\s+week|weekly)?",
            r"([€£$]?\s*\d[\d,.]*\s*(?:k|m|b|million|mil|thousand)?)\s*(?:/\s*(?:wk|week)|per\s+week)"
        ]
        for pattern in wage_patterns:
            m = re.search(pattern, text, re.I)
            if m:
                value = money_to_int(m.group(1))
                if value and value > 0:
                    result["wage"] = value
                    break
        bonus_match = re.search(r"(?:signing|sign[- ]on|upfront)\s+bonus(?:\s+(?:of|at))?\s*[:=]?\s*([€£$]?\s*\d[\d,.]*\s*(?:k|m|b|million|mil|thousand)?)", text, re.I)
        if not bonus_match:
            bonus_match = re.search(r"([€£$]?\s*\d[\d,.]*\s*(?:k|m|b|million|mil|thousand)?)\s+(?:signing|sign[- ]on|upfront)\s+bonus", text, re.I)
        if bonus_match:
            value = money_to_int(bonus_match.group(1))
            if value is not None:
                result["signing_bonus"] = max(0, value)
        years_match = re.search(r"(?<!\d)\b([1-5])\s*(?:-\s*)?years?\b", text, re.I)
        if years_match:
            result["contract_years"] = max(1, min(5, int(years_match.group(1))))
        role = normalize_role(text)
        if role:
            result["role"] = role
        return result

    async def negotiate_fee(
        self, *, player: dict[str, Any], valuation: dict[str, Any], offer_fee: int,
        buying_team_name: str, selling_team_name: str, round_no: int = 1,
        previous_pressure: int = 0, max_pressure: int = 10,
    ) -> dict[str, Any] | None:
        """Natural-language bot transfer-fee negotiation; no JSON prompt or response schema."""
        if not self.enabled:
            return None
        profile = self._player_profile(player, valuation)
        name = str(player.get("name") or "the player")
        persona = self._negotiation_persona_prompt(
            scenario="bot_fee", player_name=name,
            buying_team_name=buying_team_name, selling_team_name=selling_team_name,
        )
        prev = max(0, min(int(previous_pressure), int(max_pressure)))
        context = {
            "scenario": "bot_club_fee_negotiation", "selling_club": selling_team_name,
            "buying_club": buying_team_name, "player": profile,
            "database_valuation": valuation, "offer_fee": int(offer_fee),
            "offer_fee_display": self._money(offer_fee), "previous_pressure": prev,
            "max_pressure": int(max_pressure), "previous_pressure_bar": self._pressure_bar(prev, max_pressure),
            "round_no": int(round_no),
        }
        user_content = "PLAYER AND NEGOTIATION DATA:\n" + self._format_negotiation_context(context)
        raw = await self.chat([
            {"role": "system", "content": persona},
            {"role": "user", "content": user_content},
        ], temperature=0.7, max_tokens=1200)
        message = self._clean_user_message_text(raw or "")
        if not message or self._looks_like_reasoning_leak(message):
            return None
        ratio = float(offer_fee) / max(1, int(valuation.get("min_accept_fee") or valuation.get("market_value") or 1))
        pressure = self._natural_pressure(message, prev, max_pressure, ratio)
        accepted, walked, _ = self._natural_decision_flags(message)
        # A natural-language acceptance cannot override the club's database valuation floor.
        minimum = max(1, int(valuation.get("min_accept_fee") or round(int(valuation.get("market_value") or 0) * 0.90)))
        below_floor = int(offer_fee) < minimum
        if below_floor:
            accepted = False
        if pressure >= max_pressure:
            walked, accepted = True, False
        if walked:
            accepted = False
        bar = self._pressure_bar(pressure, max_pressure)
        message = re.sub(r"^\[Negotiation Pressure:[^\]]*\]\s*", "", message, flags=re.I).strip()
        if below_floor:
            ovr = profile.get("ovr", profile.get("overall", "N/A"))
            pot = profile.get("pot", profile.get("potential", "N/A"))
            message = (
                f"The offer of {self._money(offer_fee)} for {name} ({ovr} OVR / {pot} POT) is below our minimum acceptable valuation. "
                f"We cannot accept a fee below {self._money(minimum)}. A serious offer must meet that valuation."
            )
        message = f"{bar}\n{message or ('We accept the fee.' if accepted else 'The offer does not meet our valuation.')}"
        if not accepted and not walked and (ratio < 1.0 or below_floor) and "minimum acceptable fee" not in message.lower():
            message += f"\n\nOur valuation is {self._money(valuation.get('market_value'))}; our minimum acceptable fee is {self._money(minimum)}."
        return {"accepted": bool(accepted), "walked_away": bool(walked), "pressure": pressure,
                "pressure_bar": bar, "message": message[:3500]}

    async def negotiate_contract(
        self, *, player: dict[str, Any], demand: dict[str, Any], offered: dict[str, Any],
        previous_pressure: int = 0, max_pressure: int = 10, round_no: int = 1,
        is_free_agent: bool = False, buying_team_name: str | None = None,
        selling_team_name: str | None = None, valuation: dict[str, Any] | None = None,
        scenario: str | None = None, user_message: str | None = None,
        offered_is_explicit: bool = True, history: list[dict[str, Any]] | None = None,
        previous_manager_offer: dict[str, Any] | None = None,
        previous_agent_counter: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Natural-language contract negotiation; no JSON response format or JSON-only prompt."""
        if not self.enabled:
            return None
        profile = self._player_profile(player, valuation)
        player_name = str(player.get("name") or "The player")
        buying = str(buying_team_name or "the club")
        selling = str(selling_team_name or "the selling club")
        prev = max(0, min(int(previous_pressure), int(max_pressure)))
        sc = (scenario or ("free_agent" if is_free_agent else "contract_after_fee_agreed")).strip().lower()
        persona = self._negotiation_persona_prompt(
            scenario="free_agent" if sc == "free_agent" else "contract",
            player_name=player_name, buying_team_name=buying, selling_team_name=selling,
        )
        current_message = str(user_message or "").strip()
        context = {
            "scenario": sc, "player": profile,
            "database_stats": {"OVR": profile.get("ovr"), "POT": profile.get("pot"),
                               "market_value_eur": profile.get("market_value"),
                               "previous_weekly_wage_eur": profile.get("current_wage")},
            "selling_club": selling, "buying_club": buying, "initial_demand": demand,
            "current_manager_offer": offered,
            "previous_manager_offer": previous_manager_offer or {},
            "previous_agent_counter": previous_agent_counter or {},
            "offer_fields_explicitly_provided": bool(offered_is_explicit),
            "manager_request_interpretation": self._interpret_manager_request(current_message),
            "previous_pressure": prev, "previous_pressure_bar": self._pressure_bar(prev, max_pressure),
            "round_no": int(round_no), "is_free_agent": bool(is_free_agent),
        }
        user_content = (
            "PLAYER AND NEGOTIATION DATA:\n" + self._format_negotiation_context(context)
            + "\n\nMANAGER'S EXACT LATEST MESSAGE:\n" + (current_message or "(no message provided)")
        )
        messages: list[dict[str, str]] = [{"role": "system", "content": persona}]
        if isinstance(history, list):
            for turn in history[-12:]:
                if isinstance(turn, dict):
                    role = str(turn.get("role") or "").lower().strip()
                    content = str(turn.get("content") or "").strip()
                    if role in ("user", "assistant") and content:
                        messages.append({"role": role, "content": content[:3000]})
        messages.append({"role": "user", "content": user_content})
        raw = await self.chat(messages, temperature=0.7, max_tokens=1600)
        message = self._clean_user_message_text(raw or "")
        if not message or self._looks_like_reasoning_leak(message):
            return None

        offered_terms = self._sanitize_contract_counter(offered, fallback=demand) or dict(demand or {})
        demand_terms = self._sanitize_contract_counter(demand, fallback=offered_terms) or offered_terms
        wage_ratio = int(offered_terms.get("wage") or 0) / max(1, int(demand_terms.get("wage") or 1))
        bonus_ratio = int(offered_terms.get("signing_bonus") or 0) / max(1, int(demand_terms.get("signing_bonus") or 1))
        role_rank = {"Crucial": 0, "Important": 1, "Rotation": 2, "Sporadic": 3, "Prospect": 4}
        role_gap = role_rank.get(str(offered_terms.get("role") or "Rotation"), 2) - role_rank.get(str(demand_terms.get("role") or "Rotation"), 2)
        quality = min(wage_ratio, max(0.0, bonus_ratio) ** 0.20) - max(0, role_gap) * 0.10
        pressure = self._natural_pressure(message, prev, max_pressure, max(0.0, quality))
        accepted, walked, manager_ended = self._natural_decision_flags(message, current_message)
        # The model may not accept a materially below-demand offer just by saying "accepted".
        if wage_ratio < 0.90 or (int(demand_terms.get("signing_bonus") or 0) > 0 and bonus_ratio < 0.50) or role_gap > 1:
            accepted = False
        if manager_ended:
            accepted = walked = False
        if pressure >= max_pressure and not manager_ended:
            walked, accepted = True, False
        if walked and pressure < max_pressure:
            walked = False
        if accepted:
            walked = False

        fallback_counter = dict(previous_agent_counter or demand_terms)
        parsed_counter = self._natural_contract_terms(message, fallback_counter)
        if not (accepted or walked or manager_ended):
            manager_intent = self._interpret_manager_request(current_message)
            if "reduce its previous counter-demand" in manager_intent:
                # A non-numeric request to lower the demand triggers a modest first concession,
                # bounded by the original database-derived demand rather than an invented offer.
                previous_wage = int(fallback_counter.get("wage") or demand_terms.get("wage") or 0)
                base_wage = int(demand_terms.get("wage") or 0)
                previous_bonus = int(fallback_counter.get("signing_bonus") or demand_terms.get("signing_bonus") or 0)
                base_bonus = int(demand_terms.get("signing_bonus") or 0)
                if parsed_counter.get("wage") == previous_wage and previous_wage > base_wage:
                    parsed_counter["wage"] = max(base_wage, int(round(previous_wage * 0.95)))
                if parsed_counter.get("signing_bonus") == previous_bonus and previous_bonus > base_bonus:
                    parsed_counter["signing_bonus"] = max(base_bonus, int(round(previous_bonus * 0.90)))
        counter = None if (accepted or walked or manager_ended) else self._sanitize_contract_counter(parsed_counter, fallback=demand_terms)
        agreed = offered_terms if accepted else None
        bar = self._pressure_bar(pressure, max_pressure)
        body = re.sub(r"^\[Negotiation Pressure:[^\]]*\]\s*", "", message, flags=re.I).strip()
        if not body:
            body = "Understood. We will review the revised terms." if not accepted else "We accept the proposed terms."
        message = f"{bar}\n{body}"
        if accepted:
            message += (f"\n\n**Agreed terms:** {self._money(agreed.get('wage'))}/wk, {agreed.get('role')}, "
                        f"{self._money(agreed.get('signing_bonus'))} signing bonus, {int(agreed.get('contract_years') or 0)} years.")
        elif counter:
            message += (f"\n\n**Agent counter-demand:** {self._money(counter.get('wage'))}/wk, {counter.get('role')}, "
                        f"{self._money(counter.get('signing_bonus'))} signing bonus, {int(counter.get('contract_years') or 0)} years.")
        return {"accepted": bool(accepted), "walked_away": bool(walked), "manager_ended": bool(manager_ended),
                "pressure": int(pressure), "pressure_bar": bar, "counter": counter,
                "agreed_terms": agreed, "message": message[:3500]}

    async def generate_contract_opening(
        self,
        *,
        player: dict[str, Any],
        demand: dict[str, Any],
        valuation: dict[str, Any] | None = None,
        buying_team_name: str | None = None,
        selling_team_name: str | None = None,
        is_free_agent: bool = False,
        scenario: str | None = None,
    ) -> str | None:
        """LLM-generated opening contract negotiation message (uses prompt #2 or #3 persona)."""
        if not self.enabled:
            return None

        profile = self._player_profile(player, valuation)
        player_name = str(player.get("name") or "The player")
        buying = str(buying_team_name or "the club")
        selling = str(selling_team_name or "the selling club")
        bar = self._pressure_bar(0, 10)

        sc = (scenario or "").strip().lower()
        if not sc:
            sc = "free_agent" if is_free_agent else "contract_after_fee_agreed"

        persona = self._negotiation_persona_prompt(
            scenario="free_agent" if sc == "free_agent" else "contract",
            player_name=player_name, buying_team_name=buying, selling_team_name=selling,
        )

        context = {
            "scenario": sc,
            "player": profile,
            "player_identity": {"name": player_name, "api_id": player.get("api_id")},
            "player_database_stats": {
                "OVR": profile.get("ovr", profile.get("overall")),
                "POT": profile.get("pot", profile.get("potential")),
                "market_value_eur": profile.get("market_value"),
                "previous_weekly_wage_eur": profile.get("current_wage"),
            },
            "selling_club": selling,
            "buying_club": buying,
            "demand": demand,
            "pressure": 0,
            "max_pressure": 10,
            "pressure_bar": bar,
            "is_free_agent": bool(is_free_agent),
        }
        user_content = "PLAYER AND NEGOTIATION DATA:\n" + self._format_negotiation_context(context)

        msgs = [
            {"role": "system", "content": persona},
            {"role": "user", "content": user_content},
        ]

        msg = await self.chat(msgs, temperature=0.7, max_tokens=1400)
        msg = self._clean_user_message_text(str(msg or "").strip())

        if not msg:
            plain = await self.chat(
                [
                    {"role": "system", "content": persona},
                    {"role": "user", "content": user_content},
                ],
                temperature=0.6,
                max_tokens=1200,
            )
            if isinstance(plain, str) and plain.strip():
                cleaned_plain = self._clean_user_message_text(plain.strip()) or plain.strip()
                if not self._looks_like_reasoning_leak(cleaned_plain):
                    msg = cleaned_plain

        if not msg:
            return None

        if "[Negotiation Pressure:" not in msg:
            msg = f"{bar}\n{msg}"
        else:
            lines = msg.splitlines()
            if lines and "[Negotiation Pressure:" in lines[0]:
                lines[0] = bar
                msg = "\n".join(lines)

        # Always attach a full factual deal sheet; do not rely on the LLM to mention terms.
        wage = self._coerce_int(demand.get("wage"), 0)
        bonus = self._coerce_int(demand.get("signing_bonus"), 0)
        years = self._coerce_int(demand.get("contract_years"), 0)
        role = str(demand.get("role") or "Not specified")
        ovr = profile.get("ovr", profile.get("overall", "N/A"))
        pot = profile.get("pot", profile.get("potential", "N/A"))
        market_value = self._coerce_int(profile.get("market_value"), 0)
        previous_wage = self._coerce_int(profile.get("current_wage"), 0)
        detail_lines = [
            "**FULL CONTRACT DEMANDS**",
            f"• Weekly wage: **{self._money(wage)} per week**",
            f"• Squad role: **{role}**",
            f"• Signing bonus: **{self._money(bonus)}**",
            f"• Contract length: **{years} years**",
            "",
            "**PLAYER DATABASE PROFILE**",
            f"• Player: **{player_name}**",
            f"• Overall / Potential: **{ovr} OVR / {pot} POT**",
            f"• Current market value: **{self._money(market_value)}**" if market_value else "• Current market value: **Not available in the player database**",
            f"• Previous weekly wage: **{self._money(previous_wage)}**" if previous_wage else "• Previous weekly wage: **Not available in the player database**",
        ]
        msg = re.sub(r"\n\n\*\*FULL CONTRACT DEMANDS\*\*[\s\S]*$", "", msg).rstrip()
        # Reserve enough room so the complete factual deal sheet survives Discord's
        # embed limits and the transfer command's message-cleaning step.
        msg = msg[:1900].rstrip()
        msg += "\n\n" + "\n".join(detail_lines)
        return msg[:3400]

    # Backwards-compatible aliases used by older call sites
    async def generate_fee_negotiation_message(self, **kwargs):
        decision = await self.negotiate_fee(
            player=kwargs.get("player") or {},
            valuation=kwargs.get("valuation") or {},
            offer_fee=int(kwargs.get("offer_fee") or 0),
            buying_team_name=str(kwargs.get("buying_team_name") or ""),
            selling_team_name=str(kwargs.get("selling_team_name") or ""),
            round_no=int(kwargs.get("round_no") or 1),
            previous_pressure=int(kwargs.get("pressure") or 0),
            max_pressure=int(kwargs.get("max_pressure") or 10),
        )
        return decision.get("message") if isinstance(decision, dict) else None

    async def generate_negotiation_message(self, **kwargs):
        decision = await self.negotiate_contract(
            player=kwargs.get("player") or {},
            demand=kwargs.get("demand") or {},
            offered=kwargs.get("offered") or {},
            previous_pressure=int(kwargs.get("pressure") or 0),
            max_pressure=int(kwargs.get("max_pressure") or 10),
            round_no=int(kwargs.get("round_no") or 1),
            is_free_agent=bool(kwargs.get("is_free_agent")),
            buying_team_name=kwargs.get("buying_team_name"),
            selling_team_name=kwargs.get("selling_team_name"),
            valuation=kwargs.get("valuation"),
            scenario=kwargs.get("scenario"),
        )
        return decision.get("message") if isinstance(decision, dict) else None
